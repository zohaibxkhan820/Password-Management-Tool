package com.passwordmanagement.passwordmanagementtool.service;

import com.passwordmanagement.passwordmanagementtool.dao.interfaces.GroupDaoWrapper;
import com.passwordmanagement.passwordmanagementtool.dto.GroupDto;
import com.passwordmanagement.passwordmanagementtool.dto.UserDto;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateGroupException;
import com.passwordmanagement.passwordmanagementtool.exception.GroupDoesNotExitsException;
import com.passwordmanagement.passwordmanagementtool.service.interfaces.AccountService;
import com.passwordmanagement.passwordmanagementtool.service.interfaces.UserService;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.doThrow;

@RunWith(MockitoJUnitRunner.class)
public class GroupServiceImplTest {
    @InjectMocks
    GroupServiceImpl groupService;
    @Mock
    Authentication authentication;
    @Mock
    SecurityContext securityContext;
    @Mock
    UserService userService;
    @Mock
    GroupDaoWrapper groupDaoWrapper;
    @Mock
    AccountService accountService;
    UserDto userBean;
    GroupDto groupBean;
    private static MockedStatic<SecurityContextHolder> mockedSettings;

    @BeforeClass
    public static void init(){
        mockedSettings = mockStatic(SecurityContextHolder.class);
    }

    @AfterClass
    public static void close(){
        mockedSettings.close();
    }

    @Before
    public void setUp() {
        userBean = new UserDto();
        when(SecurityContextHolder.getContext()).thenReturn(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("name");
        when(userService.getUserByUserName(any())).thenReturn(userBean);
        groupBean = new GroupDto("abc");
    }

    @Test
    @DisplayName("Group service should save unique and encrypted group")
    public void groupServiceShouldSaveUniqueAndEncryptedGroup() {
        Assertions.assertDoesNotThrow(()->groupService.saveGroup(groupBean));
    }
    @Test
    @DisplayName("Group service should check for duplicate group")
    public void saveGroupShouldCheckForDuplicateGroup() throws DuplicateGroupException {
        doThrow(DuplicateGroupException.class).when(groupDaoWrapper).saveGroup(groupBean , userBean);
        Assertions.assertThrows(DuplicateGroupException.class,()->groupService.saveGroup(groupBean));
    }


    @Test
    @DisplayName("Group service getGroupById should return group if found")
    public void getGroupByIdShouldReturnGroupIfFound() throws GroupDoesNotExitsException {
        when(groupDaoWrapper.getGroupById(anyInt(),any())).thenReturn(groupBean);
        Assertions.assertDoesNotThrow(()->groupService.getGroupById(groupBean.getGroupId()));
    }

    @Test
    @DisplayName("getGroupById should throw exception if group not found")
    public void getGroupByIdShouldThrowExceptionIfGroupNotFound() throws GroupDoesNotExitsException{
        doThrow(GroupDoesNotExitsException.class ).when(groupDaoWrapper).getGroupById(anyInt() , any());
        Assertions.assertThrows(GroupDoesNotExitsException.class,()->groupService.getGroupById(groupBean.getGroupId()));
    }

    @Test
    @DisplayName("updateGroupById should check for duplicate group name if new group name is different")
    public void updateGroupByIdShouldCheckForDuplicateGroupNameIfGroupNameIsDifferent(){
        Assertions.assertDoesNotThrow(()->groupService.updateGroupById(1 , new GroupDto(" sdv")));

    }

    @Test
    @DisplayName("updateGroupById should check for duplicate and throw exception id duplicate")
    public void updateGroupByIdShouldCheckForDuplicateGroupNameAndThrowExceptionIfDuplicate() throws DuplicateGroupException, GroupDoesNotExitsException {
        doThrow(DuplicateGroupException.class ).when(groupDaoWrapper).updateGroupsById(anyInt() ,any() , any());
        Assertions.assertThrows(DuplicateGroupException.class,()->groupService.updateGroupById(1 , new GroupDto(" sfds")));
    }

    @Test
    @DisplayName("updateGroupById should throw exception if group does not exist")
    public void updateGroupByIdShouldThrowExceptionIfGroupDoesNotExist() throws GroupDoesNotExitsException, DuplicateGroupException {
        doThrow(GroupDoesNotExitsException.class ).when(groupDaoWrapper).updateGroupsById(anyInt() , any() ,any());
        Assertions.assertThrows(GroupDoesNotExitsException.class,()->groupService.updateGroupById(1 , new GroupDto(" sfds")));
    }
    @Test
    @DisplayName("deleteGroupById should throw exception if group does not exist")
    public void deleteByIdShouldThrowExceptionIfGroupDoesNotExist() throws GroupDoesNotExitsException {
        doThrow(GroupDoesNotExitsException.class ).when(groupDaoWrapper).deleteGroupById(anyInt() , any());
        Assertions.assertThrows(GroupDoesNotExitsException.class,()->groupService.deleteGroupById(1));
    }

    @Test
    @DisplayName("deleteGroupById should delete group if exist")
    public void deleteByIdShouldDeleteGroupIfExist(){
        Assertions.assertDoesNotThrow(()->groupService.deleteGroupById(1 ));
    }

    @Test
    @DisplayName("getAllGroups should return all groups")
    public void getAllGroupsShouldReturnAllGroups(){
        Assertions.assertDoesNotThrow(()->groupService.getAllGroups( ));
    }



}
