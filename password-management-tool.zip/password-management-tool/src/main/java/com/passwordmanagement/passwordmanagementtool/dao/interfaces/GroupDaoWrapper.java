package com.passwordmanagement.passwordmanagementtool.dao.interfaces;

import com.passwordmanagement.passwordmanagementtool.dto.GroupDto;
import com.passwordmanagement.passwordmanagementtool.dto.UserDto;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateGroupException;
import com.passwordmanagement.passwordmanagementtool.exception.GroupDoesNotExitsException;

import java.util.List;

public interface GroupDaoWrapper {
    void saveGroup(GroupDto group , UserDto userDto) throws DuplicateGroupException;
    List<GroupDto> getAllGroups(UserDto userDto) ;
    GroupDto getGroupById(int groupId , UserDto userDto) throws GroupDoesNotExitsException;
    void updateGroupsById(int groupId , GroupDto groupDto, UserDto userDto) throws GroupDoesNotExitsException, DuplicateGroupException;

    void deleteGroupById(int i, UserDto userDto) throws GroupDoesNotExitsException;
}
