package com.passwordmanagement.passwordmanagementtool.exception;

public class AccountDoesNotExitsException extends Exception {
    public   AccountDoesNotExitsException(String message) {
    }

}
