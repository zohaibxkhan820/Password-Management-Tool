package com.passwordmanagement.passwordmanagementtool.service;

import com.passwordmanagement.passwordmanagementtool.dao.interfaces.UserDaoWrapper;
import com.passwordmanagement.passwordmanagementtool.dto.UserDetailsBean;
import com.passwordmanagement.passwordmanagementtool.dto.UserDto;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateUserException;
import com.passwordmanagement.passwordmanagementtool.service.interfaces.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service("userService")
        public class UserServiceImpl implements UserService {
        @Autowired
        private UserDaoWrapper UserDaoWrapper;
        private static final Logger logger
                = LoggerFactory.getLogger(UserServiceImpl.class);

        @Override
        public void saveUser(UserDto userDto) throws DuplicateUserException {
                logger.info("saving user bean");
                userDto.setCreatedAt(new Date());
                userDto.setLastModifiedAt(new Date());
                UserDaoWrapper.saveUser(userDto);
                logger.info("User Bean saved Successfully");
        }

        @Override
        public UserDto getUserByUserName(String userName) {
                logger.info("getting user by name");
                return UserDaoWrapper.getUserByUserNAme(userName);
        }

        @Override
        public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
                logger.info("loading user by name");
                UserDto userDto = getUserByUserName(username);
                return new UserDetailsBean(userDto);
        }
}
