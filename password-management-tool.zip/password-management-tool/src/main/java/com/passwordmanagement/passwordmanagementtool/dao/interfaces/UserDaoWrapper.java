package com.passwordmanagement.passwordmanagementtool.dao.interfaces;

import com.passwordmanagement.passwordmanagementtool.dto.UserDto;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateUserException;

public interface UserDaoWrapper {
    void saveUser(UserDto UserDto) throws DuplicateUserException;
    UserDto getUserByUserNAme(String userName);

}
