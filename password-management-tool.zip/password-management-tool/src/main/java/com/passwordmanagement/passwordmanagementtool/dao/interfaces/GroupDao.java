package com.passwordmanagement.passwordmanagementtool.dao.interfaces;

import com.passwordmanagement.passwordmanagementtool.model.Group;
import com.passwordmanagement.passwordmanagementtool.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Repository
public interface GroupDao extends CrudRepository<Group,Integer> {
    int countByGroupNameAndUser(String groupName, User user);
    List<Group> findByUser(User user);
    List<Group> findByGroupIdAndUser(int groupId , User user);
}
