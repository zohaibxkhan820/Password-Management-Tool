package com.passwordmanagement.passwordmanagementtool.exception;

public class GroupDoesNotExitsException extends Exception {
    public GroupDoesNotExitsException(String message) {
        super(message);
    }
}
