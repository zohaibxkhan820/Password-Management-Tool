package com.passwordmanagement.passwordmanagementtool.exception;

public class DuplicateGroupException extends Exception{
    public DuplicateGroupException(String message) {
        super(message);
    }
}
