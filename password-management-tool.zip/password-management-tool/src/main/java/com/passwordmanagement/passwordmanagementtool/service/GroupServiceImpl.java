package com.passwordmanagement.passwordmanagementtool.service;

import com.passwordmanagement.passwordmanagementtool.dao.interfaces.GroupDaoWrapper;
import com.passwordmanagement.passwordmanagementtool.dto.AccountDto;
import com.passwordmanagement.passwordmanagementtool.dto.GroupDto;
import com.passwordmanagement.passwordmanagementtool.dto.UserDto;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateGroupException;
import com.passwordmanagement.passwordmanagementtool.exception.GroupDoesNotExitsException;
import com.passwordmanagement.passwordmanagementtool.service.interfaces.AccountService;
import com.passwordmanagement.passwordmanagementtool.service.interfaces.GroupService;
import com.passwordmanagement.passwordmanagementtool.service.interfaces.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
@Service("groupService")
public class GroupServiceImpl implements GroupService {
    @Autowired
    private GroupDaoWrapper groupDaoWrapper;
    @Autowired
    private UserService userService;
    @Autowired
    private AccountService accountService;

    private static final Logger logger
            = LoggerFactory.getLogger(GroupServiceImpl.class);
    @Override
    public void saveGroup(GroupDto groupDto) throws DuplicateGroupException {
        logger.info("saving the group bean");
        groupDto.setUser(getUserBean());
        groupDto.setCreatedAt(new Date());
        groupDto.setLastModifiedAt(new Date());
        groupDaoWrapper.saveGroup(groupDto, getUserBean());
        logger.info("group bean saved successfully");
    }

    @Override
    public List<GroupDto> getAllGroups() {
        logger.info("group bean saved successfully");
        List<GroupDto> allGroups = groupDaoWrapper.getAllGroups(getUserBean());
        List<AccountDto> unAssignedAccounts = accountService.getUnassignedAccounts();
        GroupDto groupDto = new GroupDto("un_assigned");
        groupDto.setAccounts(unAssignedAccounts);
        allGroups.add(groupDto);
        return allGroups;
    }

    @Override
    public GroupDto getGroupById(int groupId) throws GroupDoesNotExitsException {
        logger.info("getting group bean by id");
        return groupDaoWrapper.getGroupById(groupId , getUserBean());
    }
    private UserDto getUserBean()  {
        logger.info("getting user bean");
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return userService.getUserByUserName(authentication.getName());
    }


    @Override
    public void updateGroupById(int groupId, GroupDto groupDto) throws DuplicateGroupException, GroupDoesNotExitsException {
        logger.info("updating the group");
        groupDaoWrapper.updateGroupsById(groupId , groupDto, getUserBean());
        logger.info("group updated successfully");
    }

    @Override
    public void deleteGroupById(int groupId) throws GroupDoesNotExitsException {
        groupDaoWrapper.deleteGroupById(groupId , getUserBean());
    }
}
