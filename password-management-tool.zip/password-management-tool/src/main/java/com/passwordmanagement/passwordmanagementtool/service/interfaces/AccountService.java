package com.passwordmanagement.passwordmanagementtool.service.interfaces;

import com.passwordmanagement.passwordmanagementtool.dto.AccountDto;
import com.passwordmanagement.passwordmanagementtool.exception.AccountDoesNotExitsException;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateAccountException;

import java.util.List;


public interface AccountService {
    void saveAccount(AccountDto accountDto) throws DuplicateAccountException;
    AccountDto getAccountById(int accountId) throws AccountDoesNotExitsException;
    List<AccountDto> getAllAccount();
    void updateAccountById(AccountDto accountDto, int accountId) throws AccountDoesNotExitsException, DuplicateAccountException;
    void removeAccountById(int accountId) throws AccountDoesNotExitsException;

    List<AccountDto> getUnassignedAccounts();

}
