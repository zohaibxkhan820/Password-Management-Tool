package com.passwordmanagement.passwordmanagementtool.service.interfaces;

import com.passwordmanagement.passwordmanagementtool.dto.GroupDto;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateGroupException;
import com.passwordmanagement.passwordmanagementtool.exception.GroupDoesNotExitsException;

import java.util.List;

public interface GroupService {
    void saveGroup(GroupDto groupDto) throws DuplicateGroupException;
    List<GroupDto> getAllGroups() ;
    GroupDto getGroupById(int groupId) throws GroupDoesNotExitsException;
    void updateGroupById(int groupId , GroupDto groupDto) throws DuplicateGroupException, GroupDoesNotExitsException;

    void deleteGroupById(int i) throws GroupDoesNotExitsException;
}
