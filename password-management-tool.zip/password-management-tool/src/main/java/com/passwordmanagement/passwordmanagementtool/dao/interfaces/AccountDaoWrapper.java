package com.passwordmanagement.passwordmanagementtool.dao.interfaces;

import com.passwordmanagement.passwordmanagementtool.dto.AccountDto;
import com.passwordmanagement.passwordmanagementtool.dto.UserDto;
import com.passwordmanagement.passwordmanagementtool.exception.AccountDoesNotExitsException;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateAccountException;

import java.util.List;

public interface AccountDaoWrapper {
    void saveAccount(AccountDto accountDto, UserDto userDto) throws DuplicateAccountException;
    AccountDto getAccountById(int accountId , UserDto userDto) throws AccountDoesNotExitsException;
    List<AccountDto> getAllAccounts(UserDto userDto);
    void removeAccountById(int accountId , UserDto userDto) throws AccountDoesNotExitsException;
    void updateAccountById(AccountDto account, int accountId , UserDto userDto) throws AccountDoesNotExitsException, DuplicateAccountException;

    List<AccountDto> getUnAssignedAccounts(UserDto userDto);
}
