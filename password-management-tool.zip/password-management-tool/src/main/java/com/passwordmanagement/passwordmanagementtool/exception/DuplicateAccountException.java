package com.passwordmanagement.passwordmanagementtool.exception;

public class DuplicateAccountException extends Exception {
    public DuplicateAccountException(String message) {

        super(message);
    }
}
