package com.passwordmanagement.passwordmanagementtool.service.interfaces;

import com.passwordmanagement.passwordmanagementtool.dto.UserDto;
import com.passwordmanagement.passwordmanagementtool.exception.DuplicateUserException;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    void saveUser(UserDto userDto) throws DuplicateUserException;
    UserDto getUserByUserName(String userName);
}
