package com.password.tool.exception;

public class AccountDoesNotExistException extends Exception {
    public AccountDoesNotExistException(String message) {
    }
}
