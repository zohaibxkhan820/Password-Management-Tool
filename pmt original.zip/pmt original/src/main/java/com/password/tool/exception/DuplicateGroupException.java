package com.password.tool.exception;

public class DuplicateGroupException extends Exception {
    public DuplicateGroupException(String message) {
        super(message);
    }
}
